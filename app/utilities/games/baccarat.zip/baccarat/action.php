﻿<?php
while (ob_get_level()) ob_end_clean();
header('Content-Type: application/json');
error_reporting(E_ALL & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 0);


$result = array();
$result["error"] = 0;

include($_SERVER['DOCUMENT_ROOT'] ."/utilities/process/security.php");
require_once($_SERVER['DOCUMENT_ROOT'].'/control/modules/wallet.php');

$game_id = param("gid");

if($_logged){

    include("class.php");

    $action = param("action");
    $logic = new baccarat($_player->vars["id"]);
    $game = $_player->get_allowed_game($game_id);

    if(!is_null($game) && $game->vars["path"] == "baccarat"){

        switch($action){

            // =========================
            // BALANCE
            // =========================
            case "balance":

                $res = wallet_balance($_player->vars["id"]);

                if($res["success"]){
                    $balance = $res["data"];
                    if(!is_numeric($balance["real"])){$balance["real"] = 0;}
                    $result["balance"] = $balance["real"];
                }else{
                    $result["error"] = 900;
                    $result["msg"] = "Balance error: ".$res["error"];
                }

            break;

            // =========================
            // DEAL (APUESTA + RESULTADO)
            // =========================
            case "deal":

                $bets = param("bets");
                $bet_amount = 0;
                $over_limit = false;

                // provably fair
                $player_num = param("pnr");
                if(!is_numeric($player_num) || $player_num > 100000000 || $player_num < 0){$player_num = 0;}
                $player_num = round($player_num);

                // calcular monto total
                $bet_list = explode(",",$bets);
                foreach($bet_list as $bet){
                    $parts = explode("|",$bet);
                    if(is_numeric($parts[1]) && $parts[1] > 0){
                        $bet_amount += $parts[1];

                        if($parts[1] < $game->vars["min_amount"] || $parts[1] > $game->vars["max_amount"]){
                            $over_limit = true;
                        }
                    }
                }

                if(is_numeric($bet_amount)){

                    if($_player->in_between_limits($bet_amount)){

                        // obtener balance
                        $resBal = wallet_balance($_player->vars["id"]);
                        if(!$resBal["success"]){
                            $result["error"] = 900;
                            $result["msg"] = "Balance error: ".$resBal["error"];
                            break;
                        }

                        $balance = $resBal["data"];

                        if($bet_amount <= $balance["real"]){

                            if(!$over_limit){

                                // 🔥 apostar
                                $round_id = uniqid("bcrt_");

                                $res = wallet_bet(
                                    $_player->vars["id"],
                                    $bet_amount,
                                    "baccarat",
                                    $round_id,
                                    $round_id."_bet"
                                );

                                if($res["success"]){

                                    // =========================
                                    // PROVABLY FAIR
                                    // =========================
                                    if($_company->vars["prov_fair"]){

                                        $seed_data = discover_server_seed("bcrt");
                                        $pf_result = $seed_data["xnr"] + $player_num;
                                        if($pf_result > 100000000){$pf_result -= 100000000;}

                                        $result["pf"]["lxhs"] = $seed_data["xhs"];
                                        $result["pf"]["lsc1"] = $seed_data["xz1"];
                                        $result["pf"]["lsc2"] = $seed_data["xz2"];
                                        $result["pf"]["lxnr"] = $seed_data["xnr"];
                                        $result["pf"]["lpnr"] = $player_num;
                                        $result["pf"]["lpos"] = $pf_result;

                                        $logic->start_pf($pf_result);

                                        $next_seed = generate_server_seed("bcrt",0,100000000);
                                        $result["pf"]["nxnr"] = $next_seed;
                                    }

                                    // =========================
                                    // EJECUTAR JUEGO
                                    // =========================
                                    $game_result = $logic->deal($bets);
                                    $result["game_result"] = $game_result;

                                    $win_amount = round($logic->win_amount,2);
                                    $result["win_amount"] = $win_amount;

                                    // =========================
                                    // PAGAR SI GANA
                                    // =========================
                                    if($win_amount > 0){

                                        wallet_win(
                                            $_player->vars["id"],
                                            $win_amount,
                                            "baccarat",
                                            $round_id,
                                            $round_id."_win"
                                        );
                                    }

                                    // =========================
                                    // BALANCE FINAL
                                    // =========================
                                    $resBal = wallet_balance($_player->vars["id"]);

                                    if($resBal["success"]){
                                        $balance = $resBal["data"];
                                        $result["balance"] = $balance["real"];
                                    }else{
                                        $result["error"] = 900;
                                        $result["msg"] = "Balance error: ".$resBal["error"];
                                    }

                                }else{
                                    $result["error"] = 800;
                                    $result["msg"] = "Bet error: ".$res["error"];
                                }

                            }else{
                                $result["error"] = 700;
                                $result["msg"] = "Amount is not within the game limits";
                            }

                        }else{
                            $result["no_enough_balance"] = 1;
                            $result["error"] = 500;
                            $result["msg"] = "Not enough balance";
                        }

                    }else{
                        $result["not_between_limits"] = 1;
                        $result["error"] = 3745;
                        $result["msg"] = "You reached the Casino allowed limits.";
                    }

                }else{
                    $result["error"] = 600;
                    $result["msg"] = "Invalid amount";
                }

            break;

            // =========================
            // DEFAULT
            // =========================
            default :
                $result["error"] = 300;
                $result["msg"] = "Action not found.";
            break;
        }

    }else{
        $result["error"] = 345;
        $result["msg"] = "This game is not available.";
    }

}

echo json_encode($result);